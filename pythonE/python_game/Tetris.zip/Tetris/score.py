class score:
    def __init__(self):
        pass