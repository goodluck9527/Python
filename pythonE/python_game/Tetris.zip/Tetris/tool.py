def test_tool_import():
    print("Tool is working well!")