class cube:
    def __init__(self):
        pass