# encoding = utf-8
# python version: pyhon 3.6
# author: Du_Jia
# date: 2018/07/20

#import package
import time
import os

from python_game.Tetris import tool,cube, control, mainFrom,score

def main():
    tool.test_tool_import()

main()


