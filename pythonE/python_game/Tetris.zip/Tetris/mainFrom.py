class mainFrom:
    def __init__(self, cubes):
        pass

    def show_main(self):
        pass

    def refresh(self):
        pass

    def show_score(self):
        pass

    def show_next(self):
        pass

