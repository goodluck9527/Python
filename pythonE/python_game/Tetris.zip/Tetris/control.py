class control:
    def __init__(self):
        pass